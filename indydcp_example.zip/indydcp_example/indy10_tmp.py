from indy_utils import indydcp_client as client
from indy_utils.indy_program_maker import JsonProgramComponent

import json
import threading
from time import sleep
import numpy as np

robot_ip = "192.168.0.5"  # Robot (Indy) IP
robot_name = "NRMK-Indy10"  # Robot name (Indy7)indy
# robot_name = "NRMK-IndyRP2"  # Robot name (IndyRP2)

# Create class object
indy = client.IndyDCPClient(robot_ip, robot_name)

indy.connect()

indy.set_collision_level(5)
indy.set_joint_vel_level(3)
indy.set_task_vel_level(3)
indy.set_joint_blend_radius(20)
indy.set_task_blend_radius(0.2)

print(indy.get_collision_level())
print(indy.get_joint_vel_level())
print(indy.get_task_vel_level())
print(indy.get_joint_blend_radius())
print(indy.get_task_blend_radius())

j_pos = indy.get_joint_pos()
t_pos = indy.get_task_pos()

print(j_pos)
print(t_pos)

key = []
status = indy.get_robot_status()
for value in status.keys():
    key.append(value)
    
print(key)
print(type(status))
    
indy.go_home()

while True:
    status = indy.get_robot_status()
    sleep(0.2)
    if status[key[5]]==1 :
        break
print('done : go home process')

       
t_pos_rel = [0.1, 0.1, 0.1, 0, 0, 0]
indy.task_move_by(t_pos_rel)

while True:
    status = indy.get_robot_status()
    sleep(0.2)
    if status[key[5]]==1 :
        break

print('done : move1 process')


t_pos_rel = [-0.2, -0.2, -0.2, 0, 0, 0]
indy.task_move_by(t_pos_rel)

while True:
    status = indy.get_robot_status()
    sleep(0.2)
    if status[key[5]]==1 :
        break

print('done : move2 process')


indy.go_zero()

while True:
    status = indy.get_robot_status()
    sleep(0.2)
    if status[key[5]]==1 :
        break


print('done : zero process')

indy.disconnect()

