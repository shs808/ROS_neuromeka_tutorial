from indy_utils import indydcp_client as client
from indy_utils.indy_program_maker import JsonProgramComponent

import json
import threading
from time import sleep

# Set robot (server) IP 
robot_ip = "192.168.0.5"  # Robot (Indy) IP

# Set robot name
name = "NRMK-Indy10"  # Robot name (Indy7)
# name = "NRMK-IndyRP2"  # Robot name (IndyRP2)

# Create class object
indy = client.IndyDCPClient(robot_ip, name)

indy.connect()

indy.set_joint_vel_level(3)

prog = JsonProgramComponent(policy=1, resume_time=2)  # Init. prgoram

prog.add_move_home()
prog.add_move_zero()
prog.add_move_home()

prog_json = prog.program_done()    # Program end

# indy.set_and_start_json_program(prog_json) # Execute program

# indy.disconnect()

